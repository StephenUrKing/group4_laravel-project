<div class="col">
    <div class="card shadow-sm">
      <div class="card-body">
        <p class="card-text"><?php echo e($course->name); ?></p>
        <div class="d-flex justify-content-between align-items-center">
          <div class="btn-group">
            <a href="<?php echo e(route('course.show', ['course'=>$course->id])); ?>" class="btn btn-sm btn-outline-secondary">View</a>
            <?php if(Auth::user()->role =='superadmin' || 'admin'): ?>
            <a href="<?php echo e(route('course.edit', [ 'course'=>$course->id])); ?>" class="btn btn-sm btn-outline-secondary">Edit</a>
            <?php endif; ?>
            <?php if(Auth::user()->role =='superadmin'): ?>
            <button type="button" class="btn btn-outline-danger btn-sm" onclick="deleteCourse(this)">
              Delete
              <form action="<?php echo e(route('course.destroy', [ 'course'=>$course->id])); ?>" method="POST">
                  <?php echo csrf_field(); ?>
                  <?php echo method_field('DELETE'); ?>
              </form>
          </button>
          <?php endif; ?>
          </div>
          <small class="text-body-secondary"><?php echo e($course->duration); ?></small>
        </div>
      </div>
    </div>
  </div>
 <?php /**PATH C:\Users\PC\Desktop\LaravelMoi\Afrifa Yaw\Better-Deep\resources\views/components/course/course-item.blade.php ENDPATH**/ ?>