<form class="col-12 col-lg-auto mb-3 mb-lg-0 me-lg-3 justify-content-center mb-md-4 w-90 me-2" role="search">
    <input type="search" class="form-control" placeholder="<?php echo e($title); ?>" aria-label="Search">
</form>
<?php echo e($slot); ?>

<?php /**PATH C:\Users\PC\Desktop\LaravelMoi\Afrifa Yaw\Better-Deep\resources\views/components/header.blade.php ENDPATH**/ ?>