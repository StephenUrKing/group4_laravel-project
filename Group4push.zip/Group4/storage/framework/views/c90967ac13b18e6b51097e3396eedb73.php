<?php $__env->startSection('title', 'Location'); ?>

<?php $__env->startSection('content'); ?>
<div class="container my-5 py-5">

    <!--Section: Design Block-->
    <section>
        <div class="col-md-8 mb-4">
          <div class="card mb-4">
            <div class="card-header py-3">
              <h5 class="mb-0 text-font text-uppercase">Add New Location</h5>
            </div>
            <div class="card-body">

            <form action="<?php echo e($action); ?>" method="POST" enctype="multipart/form-data">
                 <?php echo csrf_field(); ?>
                 <?php if(isset($edit)): ?>
                 <?php echo method_field('PATCH'); ?>
                 <?php endif; ?>
                <div class="row mb-4">
                  <div class="col">
                    <div class="form-outline">
                      <input type="text" id="name" name="name" class="form-control  <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(request()->old('name', $alllocation->name)); ?>"/>
                      <label class="form-label" for="name">Location name</label>
                      <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                         <div class="text-danger"><?php echo e($message); ?></div>
                     <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                  </div>


                <!-- locationId -->
                <div class="form-outline mb-4">
                  <input type="text" id="locationId" name="locationId" class="form-control  <?php $__errorArgs = ['locationId'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(request()->old('locationId', $alllocation->locationId)); ?>"/>
                  <label class="form-label" for="locationId">Location ID</label>
                  <?php $__errorArgs = ['locationId'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                         <div class="text-danger"><?php echo e($message); ?></div>
                     <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <!-- description -->

                <div class="text-center">
                    <button type="submit" class="btn btn-primary btn-lg">Submit</button>
                  </div>
              </form>
            </div>

          </div>

        </div>
      </div>

    </section>
  </div>
  <script>
    document.getElementById("description").value="<?php echo e(request()->old('description', $alllocation->description)); ?>";
  </script>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('myLayout.king', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\PC\Desktop\LaravelMoi\Afrifa Yaw\Group4\resources\views/location/form.blade.php ENDPATH**/ ?>