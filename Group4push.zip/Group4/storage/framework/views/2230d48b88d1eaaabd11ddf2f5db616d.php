<?php echo $__env->make('myLayout.king', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->startSection('title', 'Students'); ?>
<?php $__env->startSection('content'); ?>

<?php $__env->startSection('title', 'Course'); ?>

<?php $__env->startSection('content'); ?>
<div class="container my-5 py-5">

    <!--Section: Design Block-->
    <section>
        <div class="col-md-8 mb-4">
          <div class="card mb-4">
            <div class="card-header py-3">
              <h5 class="mb-0 text-font text-uppercase">Add New Student</h5>
            </div>
            <div class="card-body">

            <form action="<?php echo e($action); ?>" method="POST" enctype="multipart/form-data">
                 <?php echo csrf_field(); ?>
                 <?php if(isset($edit)): ?>
                 <?php echo method_field('PATCH'); ?>
                 <?php endif; ?>
                <div class="row mb-4">
                  <div class="col">
                    <div class="form-outline">
                      <input type="text" id="name" name="name" class="form-control  <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(request()->old('name', $allstudent->name)); ?>"/>
                      <label class="form-label" for="name">Student name</label>
                    </div>
                  </div>
                  <div class="col">
                    <!-- studentId -->
                    <div class="form-outline">
                      <input type="text" id="duration" name="duration" class="form-control  <?php $__errorArgs = ['studentId'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(request()->old('studentId', $allstudent->duration)); ?>"/>
                      <label class="form-label" for="studentId">Student Id</label>
                    </div>
                  </div>
                </div>

                <!-- email -->
                <div class="form-outline mb-4">
                  <input type="text" id="email" name="email" class="form-control  <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(request()->old('email', $allstudent->email)); ?>"/>
                  <label class="form-label" for="email">Course ID</label>
                </div>

                <!-- gender -->
                <div class="form-outline mb-4">
                    <input class="form-check-input" type="radio" name="gender" id="male" value="male"
                    <?php if(request()->old('gender', $allstudent->gender) == 'male'): echo 'checked'; endif; ?>>
                <label class="form-check-label" for="male">
                    Male
                </label>
            </div>
            <div class="form-check">
                <input class="form-check-input" type="radio" name="gender" id="female" value="female"
                    <?php if(request()->old('gender', $allstudent->gender) == 'female'): echo 'checked'; endif; ?>>
                <label class="form-check-label" for="female">
                    Female
                </label>
            </div>
            <?php $__errorArgs = ['gender'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="text-danger"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
           </div>
                  <label class="form-label" for="description">Gender</label>
                </div>

                <div class="form-outline mb-4">
                    <label for="dob" class="form-label">Date of Birth</label>
                <input type="date" class="form-control" name="dob" placeholder="Date of Birth"
                    value="<?php echo e(request()->old('dob', $allstudent->dob)); ?>">
                <?php $__errorArgs = ['dob'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="text-danger"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="form-outline mb-4">
                    <label for="course_id" class="form-label">Course</label>
                    <select class="form-control" name="course_id" id="course_id">
                        <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($course->id); ?>"><?php echo e($course->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php $__errorArgs = ['department_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="error"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  </div>

                <div class="text-center">
                    <button type="submit" class="btn btn-primary btn-lg">Submit</button>
                  </div>
              </form>
            </div>

          </div>

        </div>
      </div>

    </section>
  </div>

<?php $__env->stopSection(); ?>


































<?php $__env->stopSection(); ?>

<?php echo $__env->make('myLayout.king', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\PC\Desktop\LaravelMoi\Afrifa Yaw\Better-Deep\resources\views/Student/form.blade.php ENDPATH**/ ?>