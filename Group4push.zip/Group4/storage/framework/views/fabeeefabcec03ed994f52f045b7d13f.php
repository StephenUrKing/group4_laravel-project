<?php $__env->startSection('title', 'Students'); ?>
<?php $__env->startSection('content'); ?>

<section class="py-5 text-center container">

    <div class="col-lg-6 col-md-8 mx-auto">
      <h1 class="fw-light">All Students</h1>
      <?php if(Auth::user()->role == 'superadmin' || 'admin'): ?>
        <a href="<?php echo e(route('student.create')); ?>" class="btn btn-primary my-2">Add Student</a>
      <?php endif; ?>
      </p>
    </div>


<div class="album py-5 bg-body-tertiary">
  <div class="container">
      <div class="row row-cols-1 row-cols-sm-2 row-cols-md-3 g-3">
      <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="col">
        <div class="card shadow-sm">
          <div class="card-body">
            <p class="card-text">Student Name :<?php echo e($student->name); ?></p>
            <div class="d-flex justify-content-between align-items-center">
              <div class="btn-group">
                <a href="<?php echo e(route('student.show', ['student'=>$student->student])); ?>" class="btn btn-sm btn-outline-secondary">View</a>
                <a href="<?php echo e(route('student.edit', [ 'student'=>$student->student])); ?>" class="btn btn-sm btn-outline-secondary">Edit</a>
                <button type="button" class="btn btn-outline-danger btn-sm" onclick="deletestudent(this)">
                  Delete
                  <form action="<?php echo e(route('student.destroy', [ 'student'=>$student->student])); ?>" method="POST">
                      <?php echo csrf_field(); ?>
                      <?php echo method_field('DELETE'); ?>
                  </form>
              </button>
              </div>
              <small class="text-body-secondary"><?php echo e($student->duration); ?></small>
            </div>
          </div>
        </div>
      </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</section>
<?php echo e($students->links()); ?>

<script>
  function deletestudent(buttonElement) {
      const confirmed = confirm('Are you sure you want to delete this?');
      if (confirmed) {
          const form = buttonElement.querySelector('form');
          form.submit();
      }
  }
</script>






























<?php $__env->stopSection(); ?>

<?php echo $__env->make('myLayout.king', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\PC\Desktop\LaravelMoi\Afrifa Yaw\Better-Deep\resources\views/student/list.blade.php ENDPATH**/ ?>