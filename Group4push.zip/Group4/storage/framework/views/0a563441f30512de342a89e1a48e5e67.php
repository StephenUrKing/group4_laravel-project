<?php $__env->startSection('title', 'Locations'); ?>
<?php $__env->startSection('content'); ?>

<section class="py-5 text-center container">

      <div class="col-lg-6 col-md-8 mx-auto">
        <h1 class="fw-light">All Available Locations</h1>
        <?php if(Auth::user()->role =='superadmin' || 'admin'): ?>
          <a href="<?php echo e(route('location.create')); ?>" class="btn btn-primary my-2">Add Location</a>
        <?php endif; ?>
        </p>
      </div>


 <div class="album py-5 bg-body-tertiary">
    <div class="container">
        <div class="row row-cols-1 row-cols-sm-2 row-cols-md-3 g-3">
        <?php $__currentLoopData = $locations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $location): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.location.location-item','data' => ['location' => $location]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('location.location-item'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['location' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($location)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</section>
<?php echo e($locations->links()); ?>

<script>
    function deleteLocation(buttonElement) {
        const confirmed = confirm('Are you sure you want to delete this?');
        if (confirmed) {
            const form = buttonElement.querySelector('form');
            form.submit();
        }
    }
</script>

<?php $__env->stopSection(); ?>


















<?php echo $__env->make('myLayout.king', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\PC\Desktop\LaravelMoi\Afrifa Yaw\Group4\resources\views/location/list.blade.php ENDPATH**/ ?>