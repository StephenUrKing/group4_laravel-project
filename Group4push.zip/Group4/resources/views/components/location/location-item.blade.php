<div class="col">
    <div class="card shadow-sm">
      <div class="card-body">
        <p class="card-text">{{ $location->name }}</p>
        <div class="d-flex justify-content-between align-items-center">
          <div class="btn-group">
            <a href="{{ route('location.show', ['location'=>$location->id]) }}" class="btn btn-sm btn-outline-secondary">View</a>
            @if (Auth::user()->role =='superadmin' || 'admin')
            <a href="{{ route('location.edit', [ 'location'=>$location->id]) }}" class="btn btn-sm btn-outline-secondary">Edit</a>
            @endif
            @if (Auth::user()->role =='superadmin')
            <button type="button" class="btn btn-outline-danger btn-sm" onclick="deletelocation(this)">
              Delete
              <form action="{{ route('location.destroy', [ 'location'=>$location->id]) }}" method="POST">
                  @csrf
                  @method('DELETE')
              </form>
          </button>
          @endif
          </div>
          <small class="text-body-secondary">{{ $location->duration }}</small>
        </div>
      </div>
    </div>
  </div>
