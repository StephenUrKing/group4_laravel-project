<form class="col-12 col-lg-auto mb-3 mb-lg-0 me-lg-3 justify-content-center mb-md-4 w-90 me-2" role="search">
    <input type="search" class="form-control" placeholder="{{ $title }}" aria-label="Search">
</form>
{{ $slot }}
